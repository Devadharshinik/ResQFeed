<?php
session_start();
include('config/config.php');
if (isset($_POST['login'])) {
  $donor_email = $_POST['donor_email'];
  $donor_password = sha1(md5($_POST['donor_password'])); 
  $stmt = $mysqli->prepare("SELECT donor_email, donor_password, donor_id, status FROM rqf_donors WHERE donor_email = ? AND donor_password = ?"); 
  $stmt->bind_param('ss', $donor_email, $donor_password); 
  $stmt->execute();
  $stmt->bind_result($donor_email, $donor_password, $donor_id, $status); 
  $rs = $stmt->fetch();
  if ($rs) {
    if ($status == 0) {
      $_SESSION['donor_id'] = $donor_id;
      header("location: dashboard.php");
    } elseif ($status == 1) {
      $err = "donor blocked. Contact admin.";
    }
  } else {
    $err = "Incorrect Authentication Credentials";
  }
}
require_once('partials/_head.php');
?>

<body class="bg-dark">
  <div class="main-content">
    <div class="header bg-gradient-primar py-7">
      <div class="container">
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-lg-5 col-md-6">
              <h1 style="color: #31C48D;">resQfeed</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container mt--8 pb-5">
      <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
          <div class="card bg-secondary shadow border-0">
            <div class="card-body px-lg-5 py-lg-5">
              <form method="post" role="form">
                <div class="form-group mb-3">
                  <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                    </div>
                    <input class="form-control" required name="donor_email" placeholder="Email" type="email">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    <input class="form-control" required name="donor_password" placeholder="Password" type="password">
                  </div>
                </div>
                <div class="text-center">
                  <button type="submit" name="login" class="btn btn-primary" style="background-color: #31C48D; border-color: #31C48D">Log In</button>
                  <a href="create_account.php" class=" btn btn-primary pull-right">Create Account</a>
                </div>
              </form>

            </div>
          </div>
          <div class="row mt-3">
            <div class="col-6">
              <a href="forgotpwd.php" target="_blank" style="color: #31C48D;"><small>Forgot password?</small></a> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
  require_once('partials/_footer.php');
  ?>
  <?php
  require_once('partials/_scripts.php');
  ?>
</body>
</html>