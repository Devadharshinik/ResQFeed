<?php
session_start();
include('config/config.php');
require_once('config/code-generator.php');

if (isset($_POST['reset_pwd'])) {
  if (!filter_var($_POST['reset_email'], FILTER_VALIDATE_EMAIL)) {
    $err = 'Invalid Email';
  } else {
    $reset_email = $_POST['reset_email'];

    // Check if email exists
    $checkEmail = mysqli_query($mysqli, "SELECT `donor_id`, `donor_email` FROM `rqf_donors` WHERE `donor_email` = '$reset_email'") or exit(mysqli_error($mysqli));

    if (mysqli_num_rows($checkEmail) > 0) {
      // Fetch the donor ID based on the email
      $row = mysqli_fetch_assoc($checkEmail);
      $donor_id = $row['donor_id'];

      // Hash the new password securely
      $reset_password = sha1(md5($_POST['donor_password']));

      // Update the password
      $query = "UPDATE rqf_donors SET donor_password = ? WHERE donor_id = ?";
      $postStmt = $mysqli->prepare($query);
      $rc = $postStmt->bind_param('si', $reset_password, $donor_id);
      if ($rc) {
        $postStmt->execute();
        if ($postStmt->affected_rows > 0) {
          // Password Reset Successful, then redirect
          $success = "Password Reset Successful";
          header("refresh:1; url=index.php");
        } else {
          $err = "Password reset failed";
        }
      } else {
        $err = "Please Try Again Or Try Later";
      }
      $postStmt->close();
    } else {
      $err = "No account with that email";
    }
  }
}

require_once('partials/_head.php');
?>

<body class="bg-dark">
  <div>
    <div class="main-content">
      <div class="header bg-gradient-primar py-7">
        <div class="container">
          <div class="header-body text-center mb-7">
            <div class="row justify-content-center">
              <div class="col-lg-5 col-md-6">
                <h1 style="color: #31C48D;">resQfeed</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page content -->
      <div class="container mt--8 pb-5">
        <div class="row justify-content-center">
          <div class="col-lg-5 col-md-7">
            <div class="card">
              <div class="card-body px-lg-5 py-lg-5">
                <form method="post" role="form">
                  <div class="form-group mb-3">
                    <div class="input-group input-group-alternative">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                      </div>
                      <input class="form-control" required name="reset_email" placeholder="Email" type="email">
                    </div>
                  </div>
                  <div class="form-group mb-3">
                    <div class="input-group input-group-alternative">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                      </div>
                      <input class="form-control" required name="donor_password" placeholder="New Password" type="password">
                    </div>
                  </div>
                  
                  <div class="text-center">
                    <button type="submit" name="reset_pwd" class="btn btn-primary" style="background-color: #31C48D; border-color: #31C48D">Reset Password</button>
                  </div>
                </form>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-6">
                <a href="index.php" style="color: #31C48D"><small>Log In?</small></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->
    <?php
    require_once('partials/_footer.php');
    ?>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
  </div>
</body>

</html>