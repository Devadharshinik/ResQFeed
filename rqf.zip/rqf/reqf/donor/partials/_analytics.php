<?php
$donor_id = $_SESSION['donor_id'];

$query = "SELECT COUNT(*) FROM `rqf_orders`
INNER JOIN rqf_products ON rqf_orders.prod_id = rqf_products.prod_id
WHERE rqf_products.donor_id =  '$donor_id' ";
$stmt = $mysqli->prepare($query);
if ($stmt === false) {
    die("Error in preparing the statement: " . $mysqli->error);
}
$stmt->execute();
$stmt->bind_result($orders);
$stmt->fetch();
$stmt->close();

$query = "SELECT COUNT(*) FROM `rqf_products` WHERE donor_id =  '$donor_id'";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($products);
$stmt->fetch();
$stmt->close();

$query = "SELECT SUM(pay_amt) FROM `rqf_payments`
INNER JOIN rqf_products ON rqf_payments.prod_id = rqf_products.prod_id
WHERE rqf_products.donor_id =  '$donor_id' ";
$stmt = $mysqli->prepare($query);
if ($stmt === false) {
    die("Error in preparing the statement: " . $mysqli->error);
}
$stmt->execute();
$stmt->bind_result($sales);
$stmt->fetch();
$stmt->close();
