<?php
session_start();
include('config/config.php');
if (isset($_POST['adddonor'])) {
    if (empty($_POST["donor_name"]) || empty($_POST["donor_email"]) || empty($_POST["donor_phoneno"]) || empty($_POST["donor_address"]) || empty($_POST["donor_pincode"]) || empty($_POST["donor_password"])) {
        $err = "Blank Values Not Accepted";
    } else {
        $donor_id = $_POST['donor_id'];
        $donor_name = $_POST['donor_name'];
        $donor_email = $_POST['donor_email'];
        $donor_phoneno = $_POST['donor_phoneno'];
        $donor_address = $_POST['donor_address'];
        $donor_pincode = $_POST['donor_pincode'];
        $donor_city = $_POST['donor_city'];
        $donor_password = sha1(md5($_POST['donor_password']));

        //Insert Captured information to a database table
        $postQuery = "INSERT INTO rqf_donors (donor_id, donor_name, donor_email, donor_phoneno, donor_address, donor_pincode, donor_city, donor_password) VALUES(?,?,?,?,?,?,?,?)";
        $postStmt = $mysqli->prepare($postQuery);
        if (!$postStmt) {
            // Display the error message if the preparation failed
            die('Prepare Error: ' . $mysqli->error);
        }
        
        $rc = $postStmt->bind_param('ssssssss', $donor_id, $donor_name, $donor_email, $donor_phoneno, $donor_address, $donor_pincode, $donor_city, $donor_password);
        
        if (!$rc) {
            // Display the error message if binding failed
            die('Bind Param Error: ' . $postStmt->error);
        }
        
        // Execute the statement
        if ($postStmt->execute()) {
            $success = "Donor Account Created";
            header("refresh:1; url=index.php");
        } else {
            $err = "Please Try Again Or Try Later";
            // Display the error message if execution failed
            echo 'Execute Error: ' . $postStmt->error;
        }
    }
}
require_once('partials/_head.php');
require_once('config/code-generator.php');
?>

<body class="bg-dark">
    <div class="main-content">
        <div class="header bg-gradient-primar py-7">
            <div class="container">
                <div class="header-body text-center mb-7">
                    <div class="row justify-content-center">
                        <div class="col-lg-5 col-md-6">
                            <h1 style="color: #31C48D;">resQfeed</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container mt--8 pb-5">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-7">
                    <div class="card bg-secondary shadow border-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <form method="post" role="form">
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_name" placeholder="Full Name Of Organisation" type="text">
                                        <input class="form-control" value="<?php echo $don_id;?>" required name="donor_id"  type="hidden">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_email" placeholder="Email" type="email">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_phoneno" placeholder="Phone Number" type="text">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-address-card"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_address" placeholder="Address" type="text">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-pin-3"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_pincode" placeholder="Pincode" type="text" onkeyup="fetchArea(this.value)">
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fas fa-city"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_city" id="area" placeholder="City" type="text" readonly="readonly">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group input-group-alternative">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                        </div>
                                        <input class="form-control" required name="donor_password" placeholder="Password" type="password">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="text-center">
                                        <button type="submit" name="adddonor" class="btn btn-primary ">Create Account</button>
                                        <a href="index.php" class=" btn btn-success pull-right" style="background-color: #31C48D; border-color: #31C48D">Log In</a>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    require_once('partials/_footer.php');
    ?>
    <?php
    require_once('partials/_scripts.php');
    ?>
    <script>
    function fetchArea(pincode) {
    if (pincode.length === 6) {
        const apiUrl = `https://api.postalpincode.in/pincode/${pincode}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const area = data[0]?.PostOffice[0]?.Block || 'Not found';
                document.getElementById('area').value = area;
            })
            .catch(error => {
                console.error('Error fetching area:', error);
                document.getElementById('area').value = 'Error fetching area';
            });
    } else {
        document.getElementById('area').value = '';
    }
}
</script>
</body>

</html>