<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
//Update Profile
if (isset($_POST['ChangeProfile'])) {
    $donor_id = $_SESSION['donor_id'];
    $donor_name = $_POST['donor_name'];
    $donor_email = $_POST['donor_email'];
    $donor_phoneno = $_POST['donor_phoneno'];
    $donor_address = $_POST['donor_address'];
    $donor_pincode = $_POST['donor_pincode'];
    $donor_city = $_POST['donor_city'];
    $Qry = "UPDATE rqf_donors SET donor_name =?, donor_email =?, donor_phoneno =?, donor_address =?, donor_pincode =?, donor_city =? WHERE donor_id =?";
    $postStmt = $mysqli->prepare($Qry);
    //bind paramaters
    $rc = $postStmt->bind_param('ssssssi', $donor_name, $donor_email, $donor_phoneno, $donor_address, $donor_pincode, $donor_city, $donor_id);
    $postStmt->execute();
    //declare a varible which will be passed to alert function
    if ($postStmt) {
        $success = "Account Updated" && header("refresh:1; url=dashboard.php");
    } else {
        $err = "Please Try Again Or Try Later";
    }
}
// Change Password
if (isset($_POST['changePassword'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Retrieve the current password from the database
    $getPasswordQuery = "SELECT donor_password FROM rqf_donors WHERE donor_id = ?";
    $getPasswordStmt = $mysqli->prepare($getPasswordQuery);
    $getPasswordStmt->bind_param('i', $donor_id);
    $getPasswordStmt->execute();
    $getPasswordResult = $getPasswordStmt->get_result();

    if ($getPasswordResult->num_rows === 1) {
        $row = $getPasswordResult->fetch_assoc();
        $current_password = $row['donor_password'];

        // Verify the old password (MD5 hashed)
        if (md5($old_password) === $current_password) {
            // Check if the new password matches the confirm password
            if ($new_password === $confirm_password) {
                // Hash the new password using MD5
                $hashed_new_password = md5($new_password);

                // Update the password in the database
                $updatePasswordQuery = "UPDATE rqf_donors SET donor_password = ? WHERE donor_id = ?";
                $updatePasswordStmt = $mysqli->prepare($updatePasswordQuery);
                $updatePasswordStmt->bind_param('si', $hashed_new_password, $donor_id);
                $updatePasswordStmt->execute();

                if ($updatePasswordStmt->affected_rows > 0) {
                    $success = "Password changed successfully" && header("refresh:1; url=dashboard.php");
                } else {
                    $err = "Password change failed. Please try again.";
                }
            } else {
                $err = "New password and confirm password do not match.";
            }
        } else {
            $err = "Old password is incorrect.";
        }
    } else {
        $err = "User not found.";
    }

    // Close the password retrieval statement
    $getPasswordStmt->close();
}

require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        $donor_id = $_SESSION['donor_id'];
        $ret = "SELECT * FROM  rqf_donors  WHERE donor_id = '$donor_id'";
        $stmt = $mysqli->prepare($ret);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($donor = $res->fetch_object()) {
        ?>
            <!-- Header -->
            <div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 600px; background-color: #212529;; background-size: cover; background-position: center top;">
                <!-- Mask -->
                <span class="mask bg-gradient-default opacity-8"></span>
                <!-- Header container -->
                <div class="container-fluid d-flex align-items-center">
                    <div class="row">
                        <div class="col-lg-7 col-md-10">
                            <h1 class="display-2 text-white">Hello <?php echo $donor->donor_name; ?></h1>
                            <p class="text-white mt-0 mb-5">This is your customizable profile page, where you can update information and adjust your password for enhanced security.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Page content -->
            <div class="container-fluid mt--8">
                <div class="row">
                    <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                        <div class="card card-profile shadow">
                            <div class="row justify-content-center">
                                <div class="col-lg-3 order-lg-2">
                                    <div class="card-profile-image">
                                        <a href="#">
                                            <img src="../../assets/img/user1.png" class="rounded-circle">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                                <div class="d-flex justify-content-between">
                                </div>
                            </div>
                            <div class="card-body pt-0 pt-md-4">
                                <div class="row">
                                    <div class="col">
                                        <div class="card-profile-stats d-flex justify-content-center mt-md-5">
                                            <div>
                                            </div>
                                            <div>
                                            </div>
                                            <div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <h3>
                                        Id: <?php echo $donor->donor_id; ?>
                                    
                                    </h3>
                                    <h3>
                                        Name: <?php echo $donor->donor_name; ?></span>
                                    </h3>
                                    <div class="h5 font-weight-300">
                                        <i class="ni location_pin mr-2"></i>Mail: <?php echo $donor->donor_email; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8 order-xl-1">
                        <div class="card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0">My account</h3>
                                    </div>
                                    <div class="col-4 text-right">
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post">
                                    <h6 class="heading-small text-muted mb-4">User information</h6>
                                    <div class="pl-lg-4">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label class="form-control-label" for="input-username">User Name</label>
                                                    <input type="text" name="donor_name" value="<?php echo $donor->donor_name; ?>" id="input-username" class="form-control form-control-alternative">
                                                    </div>
                                                    </div>
                                                    <div class=" col-lg-6">
                                                    <div class="form-group">
                                                        <label class="form-control-label" for="input-email">Email address</label>
                                                        <input type="email" id="input-email" value="<?php echo $donor->donor_email; ?>" name="donor_email" class="form-control form-control-alternative">
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label class="form-control-label" for="input-phoneno">Phone Number</label>
                                                    <input type="text" name="donor_phoneno" value="<?php echo $donor->donor_phoneno; ?>" id="input-phoneno" class="form-control form-control-alternative">
                                                </div>
                                                </div>
                                                <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label class="form-control-label" for="input-address">Address</label>
                                                    <input type="text" name="donor_address" value="<?php echo $donor->donor_address; ?>" id="input-address" class="form-control form-control-alternative">
                                                </div>
                                                </div>
                                                <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label class="form-control-label" for="input-pincode">Pincode</label>
                                                    <input type="text" name="donor_pincode" value="<?php echo $donor->donor_pincode; ?>" id="input-pincode" class="form-control form-control-alternative" onkeyup="fetchArea(this.value)">
                                                </div>
                                                </div>
                                                <div class="col-lg-6">
                                                <div class="form-group">
                                                    <label class="form-control-label" for="input-city">City</label>
                                                    <input type="text" name="donor_city" value="<?php echo $donor->donor_city; ?>" id="input-city" class="form-control form-control-alternative" readonly="readonly">
                                                </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <input type="submit" name="ChangeProfile" class="btn btn-success form-control-alternative" value="Submit">
                                                        </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </form>
                                                <hr>
                                                <form method =" post" action="">
                                        <h6 class="heading-small text-muted mb-4">Change Password</h6>
                                        <div class="pl-lg-4">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form-control-label">Old Password</label>
                                                        <input type="password" name="old_password" class="form-control form-control-alternative">
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form-control-label">New Password</label>
                                                        <input type="password" name="new_password" class="form-control form-control-alternative">
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <label class="form-control-label">Confirm New Password</label>
                                                        <input type="password" name="confirm_password" class="form-control form-control-alternative">
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="form-group">
                                                        <input type="submit" name="changePassword" class="btn btn-success form-control-alternative" value="Change Password">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
        }
            ?>
            </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <script>
    function fetchArea(pincode) {
    if (pincode.length === 6) {
        const apiUrl = `https://api.postalpincode.in/pincode/${pincode}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const area = data[0]?.PostOffice[0]?.Block || 'Not found';
                document.getElementById('input-city').value = area;
            })
            .catch(error => {
                console.error('Error fetching area:', error);
                document.getElementById('input-city').value = 'Error fetching area';
            });
    } else {
        document.getElementById('input-city').value = '';
    }
}
</script>
</body>

</html>