<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form method="POST">
                        <div class="mb-3">
                                <!-- Product Details -->
                                <?php
                                $pay_id = $_GET['pay_id'];
                                $ret = "SELECT * FROM rqf_payments WHERE pay_id = '$pay_id'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error);
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($pay = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Payment Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Payment Id</label><br>
                                            <p><?php echo $pay->pay_id; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Paymnet Code</label>
                                            <p><?php echo $pay->pay_code; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Payment Method</label>
                                            <p><?php echo $pay->pay_method; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Amount Paid(₹)</label>
                                            <p><?php echo '₹ ' . $pay->pay_amt; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Payment Date and Time</label>
                                            <p><?php echo date('d/M/Y g:i', strtotime($pay->created_at)) ?></p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>    
                        <div class="mb-3">
                                <!-- Product Details -->
                                <?php
                                $order_code = $_GET['order_code'];
                                $ret = "SELECT rqf_orders.*, rqf_products.* FROM rqf_orders
                                INNER JOIN rqf_products ON rqf_orders.prod_id = rqf_products.prod_id
                                WHERE rqf_orders.order_code = '$order_code'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error);
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($prod = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Order Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Order Id</label>
                                            <p><?php echo $prod->order_id; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Order Code</label>
                                            <p><?php echo $prod->order_code; ?></p>
                                        </div>
                                    </div>
                                </br>
                                    <h3 class="mb-0">Product Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Product ID</label>
                                            <p><?php echo $prod->prod_id; ?></p>
                                        </div>
                                </br>
                                        <div class="col-md-6">
                                            <label>Product Image</label><br>
                                            <img src="../admin/assets/img/products/<?php echo $prod->prod_img; ?>" height="100" width="100" alt="Product Image">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Product Code</label>
                                            <p><?php echo $prod->prod_code; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Product Name</label>
                                            <p><?php echo $prod->prod_name; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Product Price (₹)</label>
                                            <p><?php echo '₹ ' . $prod->prod_price; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Product Description</label>
                                            <p><?php echo $prod->prod_desc; ?></p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                                
                            <!-- Order Form -->
                            <div class="form-row">
                                <div class="col-md-6">
                                    <a href="payment_reports.php" class="btn btn-success">Back</a>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>
