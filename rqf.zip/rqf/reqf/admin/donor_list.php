<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529;; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
        <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            Donors List
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                    <th class="text-success" scope="col">donor ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                  $ret = "SELECT * FROM rqf_donors";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  while ($donor = $res->fetch_object()) {
                  ?>
                    <tr>
                      <th class="text-success" scope="row"><?php echo $donor->donor_id; ?></th>
                      <td><?php echo $donor->donor_name; ?></td>
                      <td><?php echo $donor->donor_email; ?></td>
                      <td><?php echo date('d/M/Y g:i', strtotime($donor->created_at)); ?></td>
                      <td>
                      <a href="donor_details.php?donor_id=<?php echo $donor->donor_id; ?>&donor_name=<?php echo $donor->donor_name; ?>">
                          <button class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i> View
                          </button>
                        </a>
                        <a href="edit_donor.php?donor_id=<?php echo $donor->donor_id; ?>&donor_name=<?php echo $donor->donor_name; ?>">
                        <button class="btn btn-sm btn-info">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                    </a>
                    <?php if ($donor->status == 0): ?>
                        <a href="bldonor.php?donor_id=<?php echo $donor->donor_id; ?>&donor_name=<?php echo $donor->donor_name; ?>">
                        <button class="btn btn-sm btn-warning">
                            <i class="fas fa-ban"></i> Block
                        </button>
                    </a>
                    <?php else: ?>
                        <a href="ubldonor.php?donor_id=<?php echo $donor->donor_id; ?>&donor_name=<?php echo $donor->donor_name; ?>">
                        <button class="btn btn-sm btn-success">
                            <i class="fas fa-check"></i> Unblock
                        </button>
                    </a>
                    <?php endif; ?>
                    <a href="deldonor.php?donor_id=<?php echo $donor->donor_id; ?>&donor_name=<?php echo $donor->donor_name; ?>">
                        <button class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </a>
                    </td>
                    </tr>
                  <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>

</body>

</html>