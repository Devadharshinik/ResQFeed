<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529;; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
        <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            Orders Records
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                    <th class="text-success" scope="col">Order ID</th>
                                    <th class="text-info" scope="col">Order Code</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Product</th>
                                    <th scop="col">Status</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                  $ret = "SELECT * FROM rqf_orders 
                  INNER JOIN rqf_products ON rqf_orders.prod_id = rqf_products.prod_id
                  INNER JOIN rqf_users ON rqf_orders.user_id = rqf_users.user_id
                  ORDER BY rqf_orders.created_at DESC";
                  $stmt = $mysqli->prepare($ret);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  while ($order = $res->fetch_object()) {
                  ?>
                    <tr>
                      <th class="text-success" scope="row"><?php echo $order->order_id; ?></th>
                      <th class="text-info" scope="row"><?php echo $order->order_code; ?></th>
                      <td><?php echo $order->user_name; ?></td>
                      <td>
                                            <?php
                                            if ($order->prod_img) {
                                                echo "<img src='../../assets/img/products/$order->prod_img' height='60' width='60 class='img-thumbnail'>";
                                            } else {
                                                echo "<img src='../../assets/img/products/default.jpg' height='60' width='60 class='img-thumbnail'>";
                                            }
                                            ?>
                    </td>
                      <td><?php echo $order->prod_name; ?></td>
                      <td><?php if ($order->prod_status == 'Blocked') {
                        echo "<span class='badge badge-danger'>Not Paid</span>";
                    } else if($order->prod_status == 'COD Order'){
                        echo "<span class='badge badge-primary'>COD</span>";
                    } else if($order->prod_price == 0){
                        echo "<span class='badge badge-info'>Free</span>";
                      } else if ($order->prod_status == 'Sold Out'){
                        echo "<span class='badge badge-success'>Paid</span>";
                      } ?></td>
                      <td><?php echo date('d/M/Y g:i', strtotime($order->created_at)); ?></td>
                      <td>
                      <a href="order_details.php?user_id=<?php echo $order->user_id; ?>&prod_id=<?php echo $order->prod_id; ?>">
                          <button class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i>
                            View Details
                          </button>
                        </a>
                    </td>
                    </tr>
                  <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>