<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
if (isset($_POST['updatecustomer'])) {
    $user_id = $_POST['user_id'];
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_phoneno = $_POST['user_phoneno'];
    $user_address = $_POST['user_address'];
    $user_pincode = $_POST['user_pincode'];
    $user_city = $_POST['user_city'];
    $Qry = "UPDATE rqf_users SET user_name =?, user_email =?, user_phoneno =?, user_address =?, user_pincode =?, user_city =? WHERE user_id =?";
    $postStmt = $mysqli->prepare($Qry);
    //bind paramaters
    $rc = $postStmt->bind_param('sssssss', $user_name, $user_email, $user_phoneno, $user_address, $user_pincode, $user_city, $user_id);
    $postStmt->execute();
    //declare a varible which will be passed to alert function
    if ($postStmt) {
        $success = "User Account Details Updated";
        header("refresh:1; url=customer_list.php");
    } else {
        $err = "Please Try Again Or Try Later";
    }
}
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form action="edit_customer.php" method="POST">
                            <div class="mb-3">
                                <!-- Product Details -->
                                <?php
                                $user_id = $_GET['user_id'];
                                $ret = "SELECT * FROM rqf_users WHERE user_id = '$user_id'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error
                                );
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($user = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Edit Customer Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-12">
                                        <label class="form-control-label" for="input-id">User Id</label>
                                        <input type="text" id="input-id" value="<?php echo $user->user_id; ?>" name="user_id" class="form-control form-control-alternative" readonly="readonly">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-username">User Name</label>
                                        <input type="text" name="user_name" value="<?php echo $user->user_name; ?>" id="input-username" class="form-control form-control-alternative">
                                        </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-email">Email address</label>
                                        <input type="email" id="input-email" value="<?php echo $user->user_email; ?>" name="user_email" class="form-control form-control-alternative">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-phoneno">Phone Number</label>
                                                    <input type="text" name="user_phoneno" value="<?php echo $user->user_phoneno; ?>" id="input-phoneno" class="form-control form-control-alternative">
                                                </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-address">Address</label>
                                                    <input type="text" name="user_address" value="<?php echo $user->user_address; ?>" id="input-address" class="form-control form-control-alternative">
                                                </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-pincode">Pincode</label>
                                                    <input type="text" name="user_pincode" value="<?php echo $user->user_pincode; ?>" id="input-pincode" class="form-control form-control-alternative" onkeyup="fetchArea(this.value)">
                                                </div>
                                                <div class="col-md-6">
                                                <label class="form-control-label" for="input-city">City</label>
                                                    <input type="text" name="user_city" value="<?php echo $user->user_city; ?>" id="input-city" class="form-control form-control-alternative" readonly="readonly">
                                                </div>     
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="form-row">
                                <div class="col-md-6">
                                <input type="submit" name="updatecustomer" class="btn btn-success form-control-alternative" value="Update Details">
                                <a href="customer_list.php" class="btn btn-primary">Back</a>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
    <script>
    function fetchArea(pincode) {
    if (pincode.length === 6) {
        const apiUrl = `https://api.postalpincode.in/pincode/${pincode}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const area = data[0]?.PostOffice[0]?.Block || 'Not found';
                document.getElementById('input-city').value = area;
            })
            .catch(error => {
                console.error('Error fetching area:', error);
                document.getElementById('input-city').value = 'Error fetching area';
            });
    } else {
        document.getElementById('input-city').value = '';
    }
}
</script>
</body>

</html>
