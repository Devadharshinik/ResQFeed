
<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="rqfsystem";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>