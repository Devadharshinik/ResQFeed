<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
if (isset($_POST['updatedonor'])) {
    $donor_id = $_POST['donor_id'];
    $donor_name = $_POST['donor_name'];
    $donor_email = $_POST['donor_email'];
    $donor_phoneno = $_POST['donor_phoneno'];
    $donor_address = $_POST['donor_address'];
    $donor_pincode = $_POST['donor_pincode'];
    $donor_city = $_POST['donor_city'];
    $Qry = "UPDATE rqf_donors SET donor_name =?, donor_email =?, donor_phoneno =?, donor_address =?, donor_pincode =?, donor_city =? WHERE donor_id =?";
    $postStmt = $mysqli->prepare($Qry);
    //bind paramaters
    $rc = $postStmt->bind_param('sssssss', $donor_name, $donor_email, $donor_phoneno, $donor_address, $donor_pincode, $donor_city, $donor_id);
    $postStmt->execute();
    //declare a varible which will be passed to alert function
    if ($postStmt) {
        $success = "Donor Account Details Updated";
        header("refresh:1; url=donor_list.php");
    } else {
        $err = "Please Try Again Or Try Later";
    }
}
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <!-- Product Details -->
                                <?php
                                $donor_id = $_GET['donor_id'];
                                $ret = "SELECT * FROM rqf_donors WHERE donor_id = '$donor_id'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error);
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($donor = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Edit Donor Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-12">
                                        <label class="form-control-label" for="input-id">Donor Id</label>
                                        <input type="text" id="input-id" value="<?php echo $donor->donor_id; ?>" name="donor_id" class="form-control form-control-alternative" readonly="readonly">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-donorname">Donor Name</label>
                                        <input type="text" name="donor_name" value="<?php echo $donor->donor_name; ?>" id="input-donorname" class="form-control form-control-alternative">
                                        </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-email">Email address</label>
                                        <input type="email" id="input-email" value="<?php echo $donor->donor_email; ?>" name="donor_email" class="form-control form-control-alternative">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-phoneno">Phone Number</label>
                                                    <input type="text" name="donor_phoneno" value="<?php echo $donor->donor_phoneno; ?>" id="input-phoneno" class="form-control form-control-alternative">
                                                </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-address">Address</label>
                                                    <input type="text" name="donor_address" value="<?php echo $donor->donor_address; ?>" id="input-address" class="form-control form-control-alternative">
                                                </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-pincode">Pincode</label>
                                                    <input type="text" name="donor_pincode" value="<?php echo $donor->donor_pincode; ?>" id="input-pincode" class="form-control form-control-alternative" onkeyup="fetchArea(this.value)">
                                                </div>
                                                <div class="col-md-6">
                                                <label class="form-control-label" for="input-city">City</label>
                                                    <input type="text" name="donor_city" value="<?php echo $donor->donor_city; ?>" id="input-city" class="form-control form-control-alternative" readonly="readonly">
                                                </div>     
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="form-row">
                                <div class="col-md-6">
                                <input type="submit" name="updatedonor" class="btn btn-success form-control-alternative" value="Update Details">
                                <a href="donor_list.php" class="btn btn-primary">Back</a>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
    <script>
    function fetchArea(pincode) {
    if (pincode.length === 6) {
        const apiUrl = `https://api.postalpincode.in/pincode/${pincode}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const area = data[0]?.PostOffice[0]?.Block || 'Not found';
                document.getElementById('input-city').value = area;
            })
            .catch(error => {
                console.error('Error fetching area:', error);
                document.getElementById('input-city').value = 'Error fetching area';
            });
    } else {
        document.getElementById('input-city').value = '';
    }
}
</script>
</body>

</html>
