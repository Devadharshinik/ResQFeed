<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
if (isset($_POST['delete'])) {
    $user_id = $_POST['user_id'];
    $Qry = "DELETE FROM rqf_users WHERE user_id = ?";
    $postStmt = $mysqli->prepare($Qry);
    // Bind parameters
    $postStmt->bind_param('s', $user_id);
    
    if ($postStmt->execute()) {
        $success = "user Deleted Successfully";
        header("refresh:1; url=customer_list.php");
    } else {
        $err = "Please Try Again Or Try Later";
    }
}
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form action="deluser.php" method="POST">
                            <div class="mb-3">
                                <!-- Product Details -->
                                <?php
                                $user_id = $_GET['user_id'];
                                $ret = "SELECT * FROM rqf_users WHERE user_id = '$user_id'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error);
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($user = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Delete user</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                    <div class="col-md-12">
                                        <label class="form-control-label" for="input-id">user Id</label>
                                        <input type="text" id="input-id" value="<?php echo $user->user_id; ?>" name="user_id" class="form-control form-control-alternative" readonly="readonly">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                    <div class="col-md-12">
                                            <label>Are you sure to delete the account of user <?php echo $user->user_name; ?></label>
                                        </div>
                                </div>
                                <?php } ?>
                            </div>
                            <div class="form-row">
                                <div class="col-md-6">
                                <input type="submit" name="delete" class="btn btn-success form-control-alternative" value="Delete">
                                    <a href="customer_list.php" class="btn btn-danger">Cancel</a>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>
