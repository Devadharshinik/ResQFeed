<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form method="POST">
                        <div class="mb-3">  
                                <?php
                                $prod_id = $_GET['prod_id'];
                                $ret = "SELECT * FROM rqf_products WHERE prod_id = '$prod_id'";
                                $stmt = $mysqli->prepare($ret);
                                if (!$stmt) {
                                    die("Error in preparing the statement: " . $mysqli->error);
                                }
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($prod = $res->fetch_object()) {
                                ?>
                                    <h3 class="mb-0">Product Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Product ID</label>
                                            <p><?php echo $prod->prod_id; ?></p>
                                        </div>
                                </br>
                                        <div class="col-md-6">
                                            <label>Product Image</label><br>
                                            <img src="../admin/assets/img/products/<?php echo $prod->prod_img; ?>" height="100" width="100" alt="Product Image">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Product Code</label>
                                            <p><?php echo $prod->prod_code; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Product Name</label>
                                            <p><?php echo $prod->prod_name; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Product Price (₹)</label>
                                            <p><?php echo '₹ ' . $prod->prod_price; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Product Description</label>
                                            <p><?php echo $prod->prod_desc; ?></p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>

                            <div class="mb-3">
                                <!-- Donor Details -->
                                <?php
                                $prod_id = $_GET['prod_id'];
                                $ret = "SELECT rqf_donors.*, rqf_products.* FROM rqf_donors
                                        INNER JOIN rqf_products ON rqf_donors.donor_id = rqf_products.donor_id
                                        WHERE rqf_products.prod_id = '$prod_id'";
                                $stmt = $mysqli->prepare($ret);
                                $stmt->execute();
                                $res = $stmt->get_result();
                                while ($data = $res->fetch_assoc()) {
                                ?>
                                    <h3 class="mb-0">Donor Details</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                    <div class="col-md-6">
                                            <label>Donor ID</label>
                                            <p><?php echo $data['donor_id']; ?></p>
                                        </div>    
                                    <div class="col-md-6">
                                            <label>Donor Name</label>
                                            <p><?php echo $data['donor_name']; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Donor Phone Number</label>
                                            <p><?php echo $data['donor_phoneno']; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Donor Email</label>
                                            <p><?php echo $data['donor_email']; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label>Donor Address</label>
                                            <p><?php echo $data['donor_address']; ?></p>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <label>Donor Pincode</label>
                                            <p><?php echo $data['donor_pincode']; ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <label>Donor City</label>
                                            <p><?php echo $data['donor_city']; ?></p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <!-- Order Form -->
                            <div class="form-row">
                                <div class="col-md-6">
                                    <a href="product_list.php" class="btn btn-success">Back</a>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
</body>

</html>
