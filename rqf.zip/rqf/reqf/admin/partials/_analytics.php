<?php
//users
$query = "SELECT COUNT(*) FROM `rqf_users` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($users);
$stmt->fetch();
$stmt->close();

//donors
$query = "SELECT COUNT(*) FROM `rqf_donors` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($donors);
$stmt->fetch();
$stmt->close();

//admins
$query = "SELECT COUNT(*) FROM `rqf_admins` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($admins);
$stmt->fetch();
$stmt->close();

//food products
$query = "SELECT COUNT(*) FROM `rqf_products` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($products);
$stmt->fetch();
$stmt->close();

//orders
$query = "SELECT COUNT(*) FROM `rqf_orders` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($orders);
$stmt->fetch();
$stmt->close();

//payement
$query = "SELECT SUM(pay_amt) FROM `rqf_payments` ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($sales);
$stmt->fetch();
$stmt->close();

//blusers
$query = "SELECT COUNT(*) FROM `rqf_users` WHERE status = 1 ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($blusers);
$stmt->fetch();
$stmt->close();

//bldonors
$query = "SELECT COUNT(*) FROM `rqf_donors` WHERE status = 1 ";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($bldonors);
$stmt->fetch();
$stmt->close();