<?php
$admin_id = $_SESSION['admin_id'];
//$login_id = $_SESSION['login_id'];
$ret = "SELECT * FROM  rqf_admins  WHERE admin_id = '$admin_id'";
$stmt = $mysqli->prepare($ret);
$stmt->execute();
$res = $stmt->get_result();
while ($admin_id = $res->fetch_object()) {

?>
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="dashboard.php">
        <img src="../../assets/img/brand.png" class="navbar-brand-img" alt="...">
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <!--<li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
          </div>
        </li>-->
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/user1.png">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <div class="dropdown-divider"></div>
            <a href="logout.php" class="dropdown-item">
              <i class="fas fa-sign-out-alt"></i>
              <span>Logout</span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="dashboard.php">
                <img src="../admin/assets/img/brand.png">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>

        <!-- Navigation -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="ni ni-tv-2 text-success"></i> Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="add_user.php">
              <i class="fas fa-user-plus text-success"></i>Add Users
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="add_donor.php">
              <i class="fas fa-users text-success"></i>Add Donors
            </a>
          </li>
        </ul>
        <!-- Divider -->
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
        <li class="nav-item">
            <a class="nav-link" href="customer_list.php">
              <i class="fas fa-user"></i> Users List
            </a>
          </li>  
          <li class="nav-item">
            <a class="nav-link" href="donor_list.php">
              <i class="fas fa-users"></i> Donors List
            </a>
          </li>  
        <li class="nav-item">
            <a class="nav-link" href="order_reports.php">
              <i class="fas fa-shopping-basket"></i> Orders Report
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="payment_reports.php">
              <i class="fas fa-rupee-sign"></i> Payments Report
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="product_list.php">
              <i class="fas fa-utensils"></i> Products List
            </a>
          </li>
        </ul>
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
        <li class="nav-item">
            <a class="nav-link" href="blocked_users.php">
              <i class="fas fa-ban text-warning"></i> Blocked Users
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="blocked_donors.php">
              <i class="fas fa-ban text-warning"></i> Blocked Donors
            </a>
          </li>
        </ul>
        <hr class="my-3">
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="fas fa-sign-out-alt text-danger"></i> Log Out
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<?php } ?>