<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
include('config/code-generator.php');
check_login();
if (isset($_POST['adddonor'])) {
    if (empty($_POST["donor_name"]) || empty($_POST["donor_email"]) || empty($_POST["donor_phoneno"]) || empty($_POST["donor_address"]) || empty($_POST["donor_pincode"]) || empty($_POST["donor_password"])) {
        $err = "Blank Values Not Accepted";
    } else {
        $donor_id = $_POST['donor_id'];
        $donor_name = $_POST['donor_name'];
        $donor_email = $_POST['donor_email'];
        $donor_phoneno = $_POST['donor_phoneno'];
        $donor_address = $_POST['donor_address'];
        $donor_pincode = $_POST['donor_pincode'];
        $donor_city = $_POST['donor_city'];
        $donor_password = sha1(md5($_POST['donor_password']));

        //Insert Captured information to a database table
        $postQuery = "INSERT INTO rqf_donors (donor_id, donor_name, donor_email, donor_phoneno, donor_address, donor_pincode, donor_city, donor_password) VALUES(?,?,?,?,?,?,?,?)";
        $postStmt = $mysqli->prepare($postQuery);
        if (!$postStmt) {
            // Display the error message if the preparation failed
            die('Prepare Error: ' . $mysqli->error);
        }
        
        $rc = $postStmt->bind_param('ssssssss', $donor_id, $donor_name, $donor_email, $donor_phoneno, $donor_address, $donor_pincode, $donor_city, $donor_password);
        
        if (!$rc) {
            // Display the error message if binding failed
            die('Bind Param Error: ' . $postStmt->error);
        }
        
        // Execute the statement
        if ($postStmt->execute()) {
            $success = "Donor Added Successfully";
            header("refresh:1; url=dashboard.php");
        } else {
            $err = "Please Try Again Or Try Later";
            // Display the error message if execution failed
            echo 'Execute Error: ' . $postStmt->error;
        }
    }
}
require_once('partials/_head.php');
?>

<body>
    <!-- Sidenav -->
    <?php
    require_once('partials/_sidebar.php');
    ?>
    <!-- Main content -->
    <div class="main-content">
        <!-- Top navbar -->
        <?php
        require_once('partials/_topnav.php');
        ?>
        <!-- Header -->
        <div style="background-color: #212529; background-size: cover;" class="header  pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body">
                </div>
            </div>
        </div>
        <!-- Page content -->
        <div class="container-fluid mt--8">
            <!-- Table -->
            <div class="row">
                <div class="col">
                    <div class="card shadow">
                        <div class="card-body">
                        <form action="add_donor.php" method="POST">
                            <div class="mb-3">
                            <h3 class="mb-0">Add Donor</h3>
                                    <hr class="my-3">
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <input class="form-control" value="<?php echo $don_id;?>" required name="donor_id"  type="hidden">
                                        <label class="form-control-label" for="input-username">Donor Name</label>
                                        <input class="form-control" required name="donor_name" placeholder="Full Name Of Organisation" type="text">
                                        </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-email">Email address</label>
                                        <input class="form-control" required name="donor_email" placeholder="Email" type="email">
                                        </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-phoneno">Phone Number</label>
                                        <input class="form-control" required name="donor_phoneno" placeholder="Phone Number" type="text">
                                                </div>
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-address">Address</label>
                                        <input class="form-control" required name="donor_address" placeholder="Address" type="text">
                                                </div>
                                    </div>
                                </br>
                                    <div class="form-row">
                                        <div class="col-md-6">
                                        <label class="form-control-label" for="input-pincode">Pincode</label>
                                        <input class="form-control" required name="donor_pincode" placeholder="Pincode" type="text" onkeyup="fetchArea(this.value)">
                                                </div>
                                                <div class="col-md-6">
                                                <label class="form-control-label" for="input-city">City</label>
                                                <input class="form-control" required name="donor_city" id="area" placeholder="City" type="text" readonly="readonly">
                                                </div>     
                                    </div>
</br>
<div class="form-row">
                                        <div class="col-md-12">
                                        <label class="form-control-label" for="input-pincode">Password</label>
                                        <input class="form-control" required name="donor_password" placeholder="Password" type="password">
                                                </div>
</div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-6">
                                <button type="submit" name="adddonor" class="btn btn-success">Add Donor</button>
                                </div>
                            </div>
                        </div>

                                </form>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <?php
            require_once('partials/_footer.php');
            ?>
        </div>
    </div>
    <!-- Argon Scripts -->
    <?php
    require_once('partials/_scripts.php');
    ?>
    <script>
    function fetchArea(pincode) {
    if (pincode.length === 6) {
        const apiUrl = `https://api.postalpincode.in/pincode/${pincode}`;
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const area = data[0]?.PostOffice[0]?.Block || 'Not found';
                document.getElementById('area').value = area;
            })
            .catch(error => {
                console.error('Error fetching area:', error);
                document.getElementById('area').value = 'Error fetching area';
            });
    } else {
        document.getElementById('area').value = '';
    }
}
</script>
</body>

</html>
